AirSpark figure set v0.35 (2026-10-26).
Editable SVG and 2x PNG figures; Chinese variants end in -zh.
Figure 2: scripts/build-rsi-figure-v035.py.
Figure 1 label patch: scripts/clarify-academy-evaluation-v035.py.
Experiment figures retain the v0.33.1 protocol.
Run export-figures.cjs with sharp installed to render PNG.
No training or measured evaluation results are included.
