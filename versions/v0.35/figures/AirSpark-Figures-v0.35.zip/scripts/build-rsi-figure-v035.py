"""Figure 2: six-stage learning cycle with a separate cross-round feedback path.

v0.35: group diagnostic stages; clarify paired validation and shared evaluation tools.
Six stages, feedback timing and the experimental protocol remain unchanged.
the manuscript's export-figures.cjs renders PNGs without changing geometry.
"""
from pathlib import Path
from html import escape

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / 'figures'
INK = '#183255'
MUTED = '#52657b'
TEAL = '#087f75'
PURPLE = '#7552a5'
LINE = '#c9d5e2'


def render(zh):
    def t(c, e): return c if zh else e
    p = [f'''<svg xmlns="http://www.w3.org/2000/svg" width="1640" height="1080" viewBox="0 0 1640 1080" role="img" aria-labelledby="title desc">
<title id="title">{t('执行与学习反馈驱动的策略自进化','Policy self-improvement through execution and learning feedback')}</title>
<desc id="desc">{t('六步主循环不变。第1和2步构成当前策略诊断，第6步包含配对评测与固定接纳决策。各用途复用学院执行与评测工具；学习反馈和整次干预记录进入记忆。','Six stages: diagnostic rollout, stage diagnosis, practice planning, expert supervision, student update, and update validation with fixed acceptance. Shared execution and evaluation tools serve different purposes. All intervention records enter memory.')}</desc>
<defs>''']
    for name, col in [('main', INK), ('exec', TEAL), ('memory', PURPLE)]:
        p.append(f'<marker id="arrow-{name}" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0 L10 5 L0 10 Z" fill="{col}"/></marker>')
    p.append(f'''</defs><rect width="1640" height="1080" fill="white"/>
<g font-family="Microsoft YaHei,Noto Sans CJK SC,Arial,sans-serif" fill="{INK}">''')

    def text(x, y, s, size=25, weight=400, col=INK, anchor='start'):
        label=escape(s)
        # Keep policy parameters as a true subscript, rather than a pi-theta product.
        label=label.replace('πθᵣ₊₁','π<tspan baseline-shift="sub" font-size="75%">θᵣ₊₁</tspan>')
        label=label.replace('πθᵣ','π<tspan baseline-shift="sub" font-size="75%">θᵣ</tspan>')
        p.append(f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{weight}" fill="{col}" text-anchor="{anchor}">{label}</text>')

    def box(x,y,w,h,num,title,lines,tint='white',accent=LINE):
        p.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="7" fill="{tint}" stroke="{accent}" stroke-width="1.8"/>')
        text(x+19,y+43,str(num),25,700,col=TEAL)
        # Two title lines make the English naming equally readable at paper width.
        for j,l in enumerate(title): text(x+51,y+43+j*31,l,27,650)
        for j,l in enumerate(lines): text(x+21,y+119+j*35,l,24 if zh else 22,col=MUTED)

    def arrow(d,kind='main'):
        col={'main':INK,'exec':TEAL,'memory':PURPLE}[kind]
        p.append(f'<path d="{d}" fill="none" stroke="{col}" stroke-width="3" stroke-linejoin="round" marker-end="url(#arrow-{kind})"/>')

    text(45,45,t('执行与学习反馈驱动的策略自进化','Policy self-improvement through execution and learning feedback'),31 if zh else 29,700)
    text(45,84,t('六步学习循环；诊断与更新验证复用执行、记录和计分工具','Six stages; shared tools support diagnosis, update validation and frozen tests'),24,col=MUTED)

    # A visual group, not a new method component: stages 1 and 2 diagnose the current policy.
    p.append(f'<rect x="25" y="112" width="770" height="308" rx="10" fill="#f7fafc" stroke="{LINE}" stroke-width="1.3"/>')
    text(45,145,t('当前策略诊断 · 采集池 C','Current-policy diagnosis · collection pool C'),23,600,col=TEAL)
    # Clockwise cycle; stage numbering and every main arrow agree.
    box(45,165,335,235,1,[t('诊断任务执行','Diagnostic rollout')],
        [t('采集池 C：学生策略 πθᵣ','Student πθᵣ; task pool C'),t('观测历史与动作命令','Observations and actions'),t('实际运动与任务结果','Motion and task outcomes')], '#eef4fd')
    box(440,165,335,235,2,[t('分阶段诊断','Stage-wise'),t('','diagnosis')] if not zh else ['分阶段诊断'],
        [t('阶段到达与转换失败','Stage reach / failure'),t('可观测性、可达性检查','Observability / feasibility'),t('频率、失败率与经验成本','Frequency, failure and cost')])
    box(845,165,355,235,3,[t('反馈驱动练习规划','Feedback-guided'),t('SparkMentor','practice planning')],
        [t('固定分配器计算 bᵣ','Fixed allocator → bᵣ'),t('选择起点、示范与回放','Choose practice η̃ᵣ'),t('执行／暂缓／诊断复验','Execute / defer / retest dᵣ')], '#eaf6f3', TEAL)
    box(845,520,355,235,4,[t('专家监督生成','Expert supervision'),t('','generation')] if not zh else ['专家监督生成'],
        [t('合法物理前缀','Legal physical prefixes'),t('固定专家执行延续','Fixed expert continuation'),t('监督质检与数据导出','Check and export labels')])
    box(440,520,335,235,5,[t('学生策略更新','Student policy'),t('','update')] if not zh else ['学生策略更新'],
        [t('新增数据与接纳回放','Qualified data + replay'),t('固定基础学习算法','Fixed learning algorithm'),t('按计划训练候选学生','Train from the plan')], '#eef4fd')
    box(45,520,335,235,6,[t('更新验证与接纳','Update validation'),t('','and acceptance')] if not zh else ['更新验证与接纳'],
        [t('V：父代／候选配对执行','V: paired policy rollouts'),t('测量：收益与能力保留','Measure gains / retention'),t('决策：接纳或保留父代','Decide: accept / retain')], '#f4f7fa')

    # Main path has no crossings. The feedback return stays below/outside it.
    arrow('M380 282 H430')
    arrow('M775 282 H835','exec')
    text(805,255,'Eᵣ',24,600,TEAL,'middle')
    arrow('M1022 400 V510')
    text(1042,459,t('计划 Aᵣ = (bᵣ, η̃ᵣ, dᵣ)','Aᵣ = (bᵣ, η̃ᵣ, dᵣ)'),20,col=TEAL)
    arrow('M845 637 H785')
    text(810,611,'Dᵣ',23,col=MUTED,anchor='middle')
    arrow('M440 637 H390')
    text(412,611,'θ′',24,col=MUTED,anchor='middle')
    arrow('M212 520 V410')
    text(230,453,t('保留策略','Retained policy'),23,col=TEAL)
    text(230,486,'πθᵣ₊₁',24,600,TEAL)

    # Memory is a record used by planning, not another learned teacher network.
    p.append(f'<rect x="1260" y="165" width="335" height="590" rx="7" fill="#f3f0f8" stroke="{PURPLE}" stroke-width="1.8"/>')
    text(1280,208,t('跨轮干预记忆','Intervention memory'),27,650)
    text(1280,251,'Mᵣ = (ℛᵣ, 𝒦ᵣ)',26,600,PURPLE)
    text(1280,310,t('ℛ：只追加事实记录','ℛ: append-only records'),24,600,PURPLE)
    text(1280,350,t('执行、计划、数据与训练','Execution / plans / data'),23,col=MUTED)
    text(1280,387,t('评价、版本、成本与决策','Training / results / costs'),23,col=MUTED)
    text(1280,422,t('接纳／拒绝／未测量','Accept / reject / missing'),22,col=MUTED)
    text(1280,455,t('𝒦：可修订教学经验','𝒦: revisable experience'),24,600,PURPLE)
    text(1280,495,t('解释、建议、条件与反证','Explanations / suggestions'),23,col=MUTED)
    text(1280,532,t('来源、状态与重测条件','Scope, evidence and retests'),23,col=MUTED)
    text(1280,617,t('先记事实，再修订经验','Record, then revise'),23,600,PURPLE)
    text(1280,655,t('成功／拒绝均更新经验','Success / rejection retained'),23,col=PURPLE)
    text(1280,691,t('按权限供下一轮读取','Permitted next-round view'),23,col=PURPLE)
    arrow('M1260 282 H1210','memory')
    text(1230,255,t('历史','Prior'),20,col=PURPLE,anchor='middle')
    arrow('M212 755 V815 H1428 V765','memory')
    # Opaque label background keeps long feedback annotation visually separate.
    p.append('<rect x="340" y="790" width="770" height="45" fill="white"/>')
    text(725,821,t('学习反馈 Fᵣ ＋ 本轮各阶段记录','Learning feedback Fᵣ + all intervention records'),24,500,PURPLE,'middle')
    # Reused facilities are annotated outside the learning path, not inserted as another stage.
    p.append(f'<rect x="45" y="855" width="1550" height="94" rx="7" fill="#f6f8fb" stroke="{LINE}" stroke-width="1.3"/>')
    text(66,890,t('共用学院工具：任务执行 → 同步记录 → 任务／阶段计分 → 评价报告',
                    'Shared tools: execute → record → score tasks / stages → report'),22,500)
    text(66,925,t('三种用途：C 当前诊断；V 更新验证；T 冻结测试。接纳由固定规则决定。',
                    'Uses: C diagnosis; V update validation; T frozen tests. Fixed rules decide acceptance.'),22,col=MUTED)
    text(45,984,t('主路径为一次训练干预；无训练尝试保留学生与配置，记录诊断结果及实际成本','Round r: Eᵣ and prior Mᵣ → practice Aᵣ → student update → Fᵣ stored in Mᵣ₊₁'),23,col=MUTED)
    text(45,1035,t('封存评价位于学习闭环之外：冻结学生 → 原生基准与物理实机；测试反馈不参与修订','Frozen tests outside the loop: benchmark and embodiment-specific real lines; no test feedback'),23,col=MUTED)
    p.append('</g></svg>')
    (OUT/('fig02-rsi-method'+('-zh' if zh else '')+'.svg')).write_text('\n'.join(p)+'\n',encoding='utf-8')


if __name__=='__main__':
    render(True)
    render(False)
    print('Generated Figure 2: six-stage cycle with correctly timed execution / learning feedback.')
