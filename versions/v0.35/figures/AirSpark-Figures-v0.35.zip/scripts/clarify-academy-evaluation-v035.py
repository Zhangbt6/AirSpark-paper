"""Clarify the shared evaluation tool in the existing academy figure; preserve geometry."""
from pathlib import Path
R=Path(__file__).resolve().parents[1]
for name,pairs in {
 'fig01-academy-overview.svg': [('Learning tools','Train and evaluate'),('Run validation and tests','Diagnose / validate / test')],
 'fig01-academy-overview-zh.svg': [('训练与评价工具','训练与统一评测'),('开发验收与独立测试','诊断／更新验证／冻结测试')]
}.items():
 p=R/'figures'/name;s=p.read_text(encoding='utf-8')
 for old,new in pairs:s=s.replace(old,new)
 p.write_text(s,encoding='utf-8')
print('Updated Figure 1 shared evaluation labels; layout unchanged.')
