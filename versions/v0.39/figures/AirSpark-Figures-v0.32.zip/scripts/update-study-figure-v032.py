from pathlib import Path
root=Path(__file__).resolve().parents[1]
p=root/'figures/fig04-evaluation-protocol-zh.svg'
s=p.read_text(encoding='utf-8')
changes={'至少两个任务，一个学生后端；记录 B0 数据、训练配方与 checkpoint': '柠檬＋NDT候选，一个学生后端；记录初始策略、数据与训练配置', '核验专家、真实本体与配准；根据实测成本确定轮次、独立学习链和预算': '先导单轮与真实场景准备；后续调整轮次、独立学习链和预算', '一个任务：原生 AM-Bench B1 vs 学院 B1，固定流程与预算一致': '真实场景重建与交互资产配准；原生来源对照列为可选', '主表：B0 冻结初始策略 ｜ B1 固定覆盖采集训练 ｜ AirSpark 完整反馈闭环': '主表：初始策略 ｜ 固定练习 ｜ AirSpark 完整反馈闭环', '一次决策选一个方案，采集训练一次，再与父代比较；按完整学习链统计': '每次一个合法计划、至多一个训练候选；以独立学习链统计', '代表任务归因：固定过程方案、规则修订、当前反馈与历史反馈': '建议组件分析：无方案修订、规则修订；当前／历史反馈可选', 'E3 · 冻结学生：AM-Bench 原生任务': 'E3 · 原生 AM-Bench 跨仿真器回测', 'B0 / B1 / 完整 AirSpark': '初始策略 / 固定练习 / 完整 AirSpark', 'E3 · 冻结学生：物理实机任务': 'E3 · Real-to-Sim-to-Real', '先核验本体与部署兼容，再定比较范围': '初始策略 / 基准场景练习 / 重建场景练习', '对应场景与预留物体／布局分别报告': '对应布局为主，预留物体／布局为可选'}
for a,b in changes.items():
    if a in s:s=s.replace(a,b,1)
p.write_text(s,encoding='utf-8')
print('Chinese evaluation figure v0.32; geometry unchanged.')
