from pathlib import Path
from html import escape
ROOT=Path(__file__).resolve().parents[1]
def render(zh):
    def t(c,e):return c if zh else e
    p=['<svg xmlns="http://www.w3.org/2000/svg" width="1440" height="1000" viewBox="0 0 1440 1000" role="img"><title>'+t('实验设计与独立验证','Experimental design and independent evaluation')+'</title><defs><marker id="arrow" viewBox="0 0 10 10" refX="9" refY="5" markerWidth="7" markerHeight="7" orient="auto"><path d="M0 0 L10 5 L0 10Z" fill="#183255"/></marker></defs><rect width="1440" height="1000" fill="white"/><g font-family="Microsoft YaHei,Arial,sans-serif" fill="#183255">']
    def text(x,y,s,size=24,bold=False):p.append(f'<text x="{x}" y="{y}" font-size="{size}" font-weight="{700 if bold else 400}">{escape(s)}</text>')
    def box(x,y,w,h,title,lines,col='#f1f5fb'):
        p.append(f'<rect x="{x}" y="{y}" width="{w}" height="{h}" rx="8" fill="{col}" stroke="#becddd"/>')
        text(x+20,y+40,title,26,True)
        for i,s in enumerate(lines):text(x+20,y+83+i*34,s,23)
    def arrow(x1,y,x2):p.append(f'<path d="M{x1} {y} H{x2}" stroke="#183255" stroke-width="3" marker-end="url(#arrow)"/>')
    text(40,45,t('实验设计与独立验证','Experimental design and independent evaluation'),32,True)
    text(40,94,t('基准线：FA-Hexa；ACT、DP、π0.5；柠檬采摘与 Push Slider','Benchmark line: FA-Hexa; ACT, DP, π0.5; lemon harvesting and Push Slider'),25,True)
    box(40,120,400,190,t('共同初始化','Matched initialization'),[t('同学生、同任务共享父代','Same student/task parent'),t('共享初始示范与输入权限','Shared task demos and inputs'),t('各架构初始化单独登记','Architecture-specific pretraining')])
    box(520,120,400,190,t('预算匹配的多轮学习','Budget-matched learning'),[t('初始策略／固定练习／完整闭环','Initial / fixed / full feedback'),t('每组 3 链，最多 4 次干预','3 chains; ≤4 interventions'),t('采集 C；开发反馈 V','Collection C; feedback V')],'#eaf6f2')
    box(1000,120,400,190,t('冻结与独立评价','Freeze and evaluate'),[t('学院内封存测试 T','Sealed academy pool T'),t('原生 AM-Bench 对应任务','Native AM-Bench return'),t('报告逐链差值与实际资源','Chain differences and resources')])
    arrow(440,215,510);arrow(920,215,990)
    text(40,370,t('独立本体实机线：DP 柠檬；不复用基准策略权重','Independent real embodiment: DP lemon; no benchmark-policy weight reuse'),25,True)
    box(40,400,400,205,t('真实任务对应与父代','Real-task match / parent'),[t('3DGS 外观＋显式物理资产','3DGS appearance + physics'),t('真实本体、相机与物理配准','Robot / camera / physics match'),t('真实＋仿真示范初始化','Real + simulated initial demos')])
    box(520,400,400,205,t('两种场景的完整闭环','Two full-loop scene sources'),[t('基准场景／重建场景练习','Benchmark / reconstructed scene'),t('同父代、预算与真实回放比例','Same parent, budget, real replay'),t('两个更新组各 3 条链','3 chains per updated group')],'#eaf6f2')
    box(1000,400,400,205,t('冻结后实机主测试','Frozen hardware test'),[t('初始：1 模型 × 30 回合','Initial: 1 model × 30 episodes'),t('更新：2 组 × 3 模型 × 10','Updated: 2 groups × 3 × 10'),t('总计 90 回合；测试不回流','90 episodes; no test feedback')])
    arrow(440,500,510);arrow(920,500,990)
    text(40,665,t('DP 柠檬的机制与扩展评价','DP lemon: component attribution and extension'),25,True)
    box(40,695,660,200,t('组件分析','Component analysis'),[t('固定／无修订／规则／无跨轮记忆／完整','Fixed / no revision / rules / current / full'),t('共享工具、信息权限与资源；历史各自独立','Same tools and caps; separate histories'),t('固定练习与完整方法复用主实验结果','Reuse primary fixed/full results')])
    box(740,695,660,200,t('跨初始化的教学经验复用','Cross-initialization experience reuse'),[t('来源链 i 的冻结经验 → 对应新父代链 i','Source Kᵢ → paired new-parent target i'),t('导入经验／空经验；两组都重新训练','Imported / empty experience; both groups train anew'),t('不导入源权重、训练轨迹或封存信息','No source weights, trajectories, or sealed information')])
    text(40,954,t('设施可靠性复用实际日志；表格和曲线待填，不预设学习或迁移效果','Facility reliability reuses actual logs; tables and curves remain unmeasured'),24)
    p.append('</g></svg>')
    (ROOT/'figures'/('fig04-evaluation-protocol'+('-zh' if zh else '')+'.svg')).write_text('\n'.join(p),encoding='utf-8')
if __name__=='__main__':
    render(True);render(False)
